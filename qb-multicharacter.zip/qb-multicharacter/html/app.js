document.addEventListener("DOMContentLoaded", () => {
    const app = new Vue({
        el: "#app",
        data: {
            characters: [],
            show: {
                register: false,
            }
        },
        mounted() {
            // Load characters (for simplicity, mock data)
            this.characters = { 1: null }; // Only one slot available
        }
    });
});