Config = Config or {}

-----------------
--MZ-SCOREBOARD--
-----------------

Config.KeyTrigger = "HOME"

Config.minBanks = 5

Config.minVangellico = 4

Config.minShopRobbery = 3

Config.CornerSelling = 2

Config.HouseRobberies = 1